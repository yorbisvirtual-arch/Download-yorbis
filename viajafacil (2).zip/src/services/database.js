// Firebase config placeholder
export const db = {};