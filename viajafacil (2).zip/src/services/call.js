// Call service placeholder
export const startVoipCall = () => {};